package com.example.uts.model;

public class BukuEntity {
    public String _id;
    public String Judul;
    public Double Harga;
    public String Deskripsi;
}
