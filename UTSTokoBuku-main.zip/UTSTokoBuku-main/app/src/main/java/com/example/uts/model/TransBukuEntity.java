package com.example.uts.model;

public class TransBukuEntity {
    public String _id;
    public String Tanggal;
    public Double Total;
    public Double JumlahBarang;
    public Double Bayar;
    public Double Kembali;
}
