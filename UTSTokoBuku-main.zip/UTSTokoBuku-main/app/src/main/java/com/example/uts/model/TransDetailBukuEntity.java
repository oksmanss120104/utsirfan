package com.example.uts.model;

public class TransDetailBukuEntity {
    public String _id;
    public String TransId;
    public String BukuId;
    public String Judul;
    public Double Harga;
    public Double Jumlah;
    public Double Subtotal;
}
